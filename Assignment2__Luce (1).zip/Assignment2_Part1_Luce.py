# Geog 565 2016 Assignment 2 Part 1
# Name: Alina Luce
# Date: 04/14/2018

# Directions: Using all the data in the Exercise06 folder, create a script that copies all of the
# point and line (not polygon) feature classes into a new database that the script creates.
# This script looks at all of the feature classes in a workspace and copies all of the point and
# line feature classes into a new database that the script creates.

# import modules
import arcpy
from arcpy import env

# set workspace
arcpy.env.workspace = "C:/EsriPress/Python/Data/Exercise06"

# allow overwriting ##This seems to work 90% of the time, which is weird. 
arcpy.env.overwriteOutput = True

# create new geodatabase
arcpy.CreateFileGDB_management("C:/EsriPress/Python/Data/Exercise06/Results", "Assn2.gdb")

# print out that the geodatabase was successfully created (this is very nice for the user, but not necessary for the script's purpose
if arcpy.Exists(fc): 
    print "Geodatabase successfully created!"

# set a variable equal to a list of the feature classes in the workspace
# use an arcpy function to do this
fclist = arcpy.ListFeatureClasses()

# loop through each feature class in the list of feature classes
fclist = [u'amtrak_stations.shp', u'cities.shp', u'counties.shp', u'new_mexico.shp', u'railroads.shp']
for item in fclist:
    print item

# use arcpy.Describe to set variables to the feature class name and shapeType
for fc in fclist:
    fcdescribe = arcpy.Describe(fc)
    print "Name: " + fcdescribe.name
    print "Data type: " + fcdescribe.shapeType

### This section below is chaos. Matt, you mentioned loops when I emailed you, but I think my issue is
    ## that I don't know how to specify Point/Polyline in order to direct my loop.  From there, I can't
    ## check the rest of my code because it keeps getting caught up on this section. Will you be sending
    ## out the correct code/answer for each assingment? It would be really helpful.
# if the shapeType is Point or Polyline, add it to the new geodatabase
# Set local variables
point = arcpy.ListFeatureClasses("","point","")
polyline = arcpy.ListFeatureClasses("","polyline","")
polygon = arcpy.ListFeatureClasses("","polygon","")

if point or polyline:
    in_features = ['point', 'polyline']
    out_location = 'C:\EsriPress\Python\Data\Exercise06\Results\Assn2.gdb'
 
# Execute FeatureClassToGeodatabase
arcpy.FeatureClassToGeodatabase_conversion('point' + 'polyline', 'C:\EsriPress\Python\Data\Exercise06\Results\Assn2.gdb')
####This section above is chaos. 

# Execute Copy ####I know slashes won't run. It's just supposed to indicate that whatever comes out of
# the above is supposed to go here below. ####
arcpy.Copy_management(amtrak_stations_shp/input, amtrak_stations_copy/output)

# otherwise, if the shapeType is Polygon, do nothing
if polygon:
    print (None)

# add print statements as needed so the user knows what's going on when they run the script!
#Isn't that exactly what these green comments you have are? 

