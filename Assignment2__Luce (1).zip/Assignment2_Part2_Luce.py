# Geog 565 2016 Assignment 2 Part 2
# Name: Alina Luce
# Date: 04/15/2018

# Directions: Using the lakes.shp file from the Exercise 2 folder, create a script that adds a new field
# called AreaClass (type Text), and then uses the AREA_ column to classify each lake as "Small",
# "Medium", or "Large" in this field. This script adds a new field to a shapefile, then populates it
# with the size classification.

# Small - Area less than 35000
# Medium - Area greater than or equal to 35000 and less than 120000 feet
# Large - Area greater than or equal to 120000 feet

# import modules
import arcpy

# set workspace
arcpy.env.workspace = "C:/EsriPress/Python/Data/Exercise02/Results"

##At this point, my brain stopped coding. So I went to Model builder and built a model that worked,
## then exported over the code. Here it is. ***Why did the fields have to be nullable?
# Local variables:
lakes = "lakes"
lakes_selection1 = "C:\\EsriPress\\Python\\Data\\Exercise06\\Results\\Assn2.gdb\\lakes_selection1"
lakes_selection1__3_ = lakes_selection1
lakes_selection2 = "C:\\EsriPress\\Python\\Data\\Exercise06\\Results\\Assn2.gdb\\lakes_selection2"
lakes_selection2__2_ = lakes_selection2
lakes_selection3 = "C:\\EsriPress\\Python\\Data\\Exercise06\\Results\\Assn2.gdb\\lakes_selection3"
lakes_selection3__3_ = lakes_selection3

# Process: Select
arcpy.Select_analysis(lakes, lakes_selection1, "\"AREA_\" < 3500")

# Process: Add Field
arcpy.AddField_management(lakes_selection1, "Small", "TEXT", "", "", "", "Small", "NULLABLE", "NON_REQUIRED", "")

# Process: Select (2)
arcpy.Select_analysis(lakes, lakes_selection2, "\"AREA_\" >= 3500 AND \"AREA_\" <120000")

# Process: Add Field (2)
arcpy.AddField_management(lakes_selection2, "Medium", "TEXT", "", "", "", "Medium", "NULLABLE", "NON_REQUIRED", "")

# Process: Select (3)
arcpy.Select_analysis(lakes, lakes_selection3, "\"AREA_\" >= 120000")

# Process: Add Field (3)
arcpy.AddField_management(lakes_selection3, "Large", "TEXT", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")

##So because I used ModelBuilder, I didn't need to do this, I think...did I?

(# We need to make changes to the attribute table, and to do that we need to create an update cursor
# Use the AREA_ field and the new AreaClass field in the cursor
# populate AreaClass based on the value in AREA_ specified in the Directions
    # loop though the cursor
        # if area is small, define AreaClass as Small
        # if area is medium, define AreaClass as Medium
        # if area is large, define AreaClass as Large
        # update the row with the appropriate value - Don't forget this step!
# delete your row variable
# delete your cursor variable)

##I am really frustrated right now. This assignment took me 11 hours to do (two hours on Friday, and then
## today from 7:30AM to 5:14 PM, and in the end I feel like I did a hot mess of a job, working around
## things and guessing until until something stuck to the proverbial wall. It should not have taken that
## long. Obviously I am not picking things up fast enough, but I feel like I have poured time and effort
## into this, despite my millions of questions and constant confusion. I have spent more hours on this
## class this week than I have on my job. It just is not clicking, and it seems like I'm always just
## "missing something". I understand this is super basic stuff to you guys probably, and that it can be
## maddening when people don't get it, but I just don't. Granted, starting my job the week before class
## started has made things extra challenging, but I don't see how I am at a snapping point on the second
## week's assignment.
##OK, vent complete. I am really interested in this subject and am frustrated by how little progress I
## seem to be making. I don't think I am the only one in the class who is having problems, but perhaps so.
## Just wanted to share where I was at, in case I am not the only one. 