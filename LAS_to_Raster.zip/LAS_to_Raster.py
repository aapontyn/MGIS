#Final Project - Elephant Shrews
#Date: June 6, 2018
#Marco Brettman, Alina Luce, Nathaniel Santa Cruz

#Tool Name: LAS to Mosaic Dataset
#Description: Selects all LAS files in a folder and outputs a single raster

import arcpy
import os

#Select LAS Data Folder
DataFolder = arcpy.GetParameterAsText(0)
arcpy.env.workspace = DataFolder
arcpy.env.overwriteOutput = True

#Create variable that will list all LAS files in the folder
LasFiles = arcpy.ListFiles("*.las")
print "The following LAS files will be used:"
print LasFiles

#Create LAS Dataset
LasDataset = os.path.join(DataFolder, "LAS_Dataset.lasd")
arcpy.CreateLasDataset_management(LasFiles, LasDataset)
print "LAS Dataset has been created"

#Set Processing Extent to the LAS Dataset
arcpy.env.extent = LasDataset 

#Convert LAS Dataset to Raster
LasRaster = arcpy.GetParameterAsText(1)
arcpy.LasDatasetToRaster_conversion(LasDataset,LasRaster)
print "Raster has been created"

#Delete LAS Dataset
arcpy.Delete_management(LasDataset)
print "LAS Dataset has been removed"

