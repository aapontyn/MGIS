# Instructions:
# Create a script that determines if a list of integers contains duplicates.
# If it does contain duplicates, print out "This list contains duplicates".
# If the list does NOT contain duplicates, print out the smallest number in the list.
# Use the following lists for testing: [2, 8, 64, -16, 32, 4, 16, 8, -30] and [2, 8, 64, -16, 32, 4, 16, 18, -30]


# Name: [Alina Luce 
# Date: 04/08/18
# Assignment 1 Part 1
# This script determines if a list of integers contains duplicates.

#list1 = [2, 8, 64, -16, 32, 4, 16, 8, -30]
#list2 = [2, 8, 64, -16, 32, 4, 16, 18, -30]

#if yes "This list contains duplicates"
#if not, print smallest#

# your code here
list1 = [2, 8, 64, -16, 32, 4, 16, 8, -30]
list2 = [2, 8, 64, -16, 32, 4, 16, 18, -30]

list.sort(list1)
list.sort(list2)

if len(list1) <> len(set(list1)):
     print("This list contains duplicates")
else:
    print(list1[0])


if len(list2) <> len(set(list2)):
     print("This list contains duplicates")
else:
     print(list1[0])

