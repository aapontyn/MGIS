# Use string slicing to print out each word of the following string
# "Geographic Information Systems" one word at a time.

# Name: Alina Luce  
# Date: 04/08/18
# Assignment 1 Part 3
# This script uses string slicing to print out different words in a string.

myString = 'Geographic Information Systems'

# use slicing to print just the first word
mystring = "Geographic Information Systems"
print(mystring[0:10])

# use slicing to print just the second word
mystring = "Geographic Information Systems"
print(mystring[11:22])

# use slicing to print just the third word
mystring = "Geographic Information Systems"
print(mystring[22:32])

# BONUS: use slicing to print the entire string backwards
mystring = "Geographic Information Systems"
print(mystring[::-1])
