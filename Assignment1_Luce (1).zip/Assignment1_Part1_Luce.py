# Instructions: 
# Create a script that examines the following string for a particular letter. 
# "Python in GIS makes work easier".
# If the string does contain your letter, the script should print
# "Yes, the string contains the letter."
# If not, the script should print "No, the string does not contain the letter."


# Name: Alina Luce  
# Date: 04/08/18
# Assignment 1 Part 1
# This script examines a string for a particular letter.

#enter code here
myLetter = 'a'
myString = 'Python in GIS makes work easier'
if 'a' in myString:
    print('Yes, the string contains the letter.')
else:
     print('No, the string does not contain the letter.')
