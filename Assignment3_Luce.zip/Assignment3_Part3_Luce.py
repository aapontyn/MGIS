# Geog 565 2016 Assignment 3 Part 3
# Name: Alina Luce
# Date: 04/20/2018

# Directions: Using the q1222.dem file in the NSeattleDEM folder included in the starter zip,
# create a contour file that uses an interval that the user specifies. You must use arcpy.GetParameterAsText for this.
# Be sure to test your script using different intervals.

# import arcpy
import arcpy

# import arcpy.sa
from arcpy import env
from arcpy.sa import *

# get your interval from the user using arcpy.GetParameterAsText
interval = arcpy.GetParameterAsText(0)
interval = float(interval)
print interval
print type(interval)

# set your environment variables
workspace = 'C:/EsriPress/Python/Data/Exercise09/NSeattleDEM'
arcpy.env.workspace = workspace
arcpy.env.overwriteOutput = True
dem = 'C:/EsriPress/Python/Data/Exercise09/NSeattleDEM/q1222.dem'
fcName = "Contours"
output = workspace + "/" + fcName

# check out the Spatial Analyst extention if its available
if arcpy.CheckExtension("spatial") == "Available":
    arcpy.CheckOutExtension("spatial")

# do the contouring
arcpy.sa.Contour(dem, output, interval)  

# check in the Spatial Analyst extention
arcpy.CheckInExtension("spatial")

print "It's donnnne!"