# Geog 565 2016 Assignment 3 Part 2
# Name: Alina Luce
# Date: 04/20/2018

# Directions: Write a script that creates a new raster that meets certain
# slope, aspect, and land cover conditions. You will use the elevation and
# landcover.tif files from the Exercise 9 data folder. Here is the criteria:

# import arcpy
import os
import sys
import arcpy

# import arcpy.sa
from arcpy import env
from arcpy.sa import *

# set workspace
workspace = "C:\EsriPress\Python\Data\Exercise09"
arcpy.env.workspace = workspace
env.overwriteOutput = True

# check if the Spatial Analyst extention is available
    # check out the Spatial Analyst extention
if arcpy.CheckExtension("spatial") == "Available":
    arcpy.CheckOutExtension("spatial")
    
# create a Raster object for your elevation
elev = arcpy.Raster("elevation")
          
# create a Raster object for your landcover
lc = arcpy.Raster("landcover.tif")

# create slope and aspect variables to hold Slope and Aspect objects
slope = Slope(elev, "DEGREE")
aspect = Aspect(elev)

# Moderate slope: between 10 and 20 degrees 
# Northeast aspect: between 0 and 90 degrees 
# Forested: land cover types of 41, 42, or 43

## We talked about the pros and cons of RemapRange and good:-
##can you provide any insight on this? Is one better for some
##things than others? How are they different? Are they different?

# create a variable and assign it to your slope calculation
goodslope = ((slope > 10) & (slope < 20))

# create a variable and assign it to your aspect calculation
goodaspect = ((aspect > 0) & (aspect < 90))

##I'd imagine you need one for the forested apecification as well?
goodland = ((lc == 41) & (lc == 42) & (lc == 43))

# calculate the final output
outraster = (goodslope & goodaspect & goodland)

# save the output
outraster.save("C:\EsriPress\Python\Data\Exercise09\myraster")

# check in the Spatial Analyst Extention
arcpy.CheckInExtension("spatial")

# Be done.
print "Done did it" 
## in arcmaps, this is just a giant green square. Is this really what we want?
