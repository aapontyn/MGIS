# Geog 565 2016 Assignment 3 Part 1
# Name: Alina Luce
# Date: 04/20/2018

# This script takes in a text file containing coordinates and turns it into a point shapefile.

# Directions: Create a Point shapefile that contains points whose coordinates are obtained 
# from the Assignment3_pointData.txt file, included in the Assignment3 starter package.
# Examine the content of this file before you begin. It contains an object ID and x y coordinates.
# Use the comments below to guide you, though feel free to ignore them and do it your own way. 

# File contents:
# OID: The object ID
# X: The x coordinate
# Y: The y coordinate
# Each point (coordinate pair x, y) in the text file becomes a point in the shapefile.

# import arcpy
import arcpy
import fileinput
import string
import os
from arcpy import env

# set up your workspace and environment
arcpy.env.workspace = r"C:\EsriPress\Python\Data\Exercise08"
arcpy.env.overwriteOutput = True

# create necessary variables
# create a variable to hold your new shapefile's name
outpath = "C:/EsriPress/Python/Data/Exercise08"
newfc = "newpoint.shp"
point = arcpy.Point()

# create a new featureclass in your workspace and make it type "Point"
arcpy.CreateFeatureclass_management(outpath, newfc, "Point")

# open textfile in readmode
infile = "C:/EsriPress/Python/Data/Exercise08/Geog565_Assignment3_Starter/Assignment3pointData.txt"

# Create a list of all the lines in the file, but be sure to exclude the header!------------------------
filename = open(infile, "r")
data = filename.readlines(1:)
filename.close()
##readline funct- see class notes
##put lines in...see interactive window. use string statements to break up. need to split strings into integers, then into points.
##above, filename equals opening and locking textfile. immediately put close at end of script so you don't forget it. 

# Create an Insert Cursor and give it your new feature class and the list of fields
# The geometry field you need is "SHAPE@XY"
# It is recomended that you create the cursor with a 'with' statement, though you don't have to
## with statement replaces insert cursor line, would need to tab out all below to make formatting appropriate
##it is functional as is, just another way to do it

cursor = arcpy.da.InsertCursor(newfc, ["SHAPE@XY"])

# Loop through the lines in your text file (except the 
        # split the values using the split() function. (i.e. values = line.split(";")
        # assign variables to your x and y (use the index of the split values), you will need to cast your x and y as floats
        # create a rowValue variable to hold the list of attributes
for line in data:
    point.ID, point.X, point.Y = line.split(';')
    cursor.insertRow([point])   

del cursor
# delete the cursor variable (unless you create the cursor with 'with' in which case it is automatically deleted)

# close the file
##closed previously
